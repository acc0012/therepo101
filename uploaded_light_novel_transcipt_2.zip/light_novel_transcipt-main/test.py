import os
import subprocess
import telebot
import gdown
from gpt4all import GPT4All

# --- Config ---

drive_url = "https://drive.google.com/uc?id=1c2XOp78-KgIECyMWpvhKyDVj74KiFv5L"
model_dir = "models"
model_name = "Meta-Llama-3-8B-Instruct.Q4_0.gguf"
model_path = os.path.join(model_dir, model_name)
output_file = "file.txt"

CHAT_ID = os.getenv("C_ID")
BOT_TOKEN = os.getenv("TOKEN")

# --- Step 1: Download model if not exists ---

os.makedirs(model_dir, exist_ok=True)

if not os.path.exists(model_path):
    print("📥 Downloading model from Google Drive...")
    try:
        gdown.download(drive_url, model_path, quiet=False, fuzzy=True, resume=True)
    except Exception as e:
        print(f"⚠️ gdown failed: {e}")
        print("👉 Falling back to curl...")
        try:
            subprocess.run(["curl", "-L", drive_url, "-o", model_path], check=True)
            print("✅ Model downloaded with curl")
        except subprocess.CalledProcessError as ce:
            print(f"❌ curl failed: {ce}")
            exit(1)
else:
    print("✅ Model already exists locally")

# --- Step 2: Load model ---

print("📥 Loading model...")
model = GPT4All(model_name, model_path=model_dir, device="cpu")
print("✅ Model loaded successfully")

# --- Step 3: Define test prompt ---

prompt = """Give Node.js Express code to make CRUD operations
with simple explanations in comments only code nothing more than that"""

# --- Step 4: Generate output ---

summary_tokens = []
with model.chat_session():
    for token in model.generate(prompt, max_tokens=1000, streaming=True):
        summary_tokens.append(token)

result_text = "".join(summary_tokens).strip()

# --- Step 5: Save to file.txt ---

with open(output_file, "w", encoding="utf-8") as f:
    f.write(result_text)

print(f"✅ Output saved to {output_file}")

# --- Step 6: Send file to Telegram ---

def send_file_to_telegram(file_name: str):
    bot = telebot.TeleBot(BOT_TOKEN)
    if not os.path.exists(file_name):
        print(f"❌ File {file_name} not found")
        return
    with open(file_name, "rb") as f:
        bot.send_document(CHAT_ID, f, caption=f"📂 File sent: {file_name}")
    print(f"✅ File '{file_name}' sent to Telegram successfully")

if os.path.exists(output_file):
    send_file_to_telegram(output_file)

